package com.tutorial;

public class Main {
    public static void main(String[] args) {
        // membuat objek
        player player1 = new player("himura");
        player1.cetak();
    }
}
