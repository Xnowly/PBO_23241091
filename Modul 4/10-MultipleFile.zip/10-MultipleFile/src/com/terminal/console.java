package com.terminal;

public class console {
    public static void log (String pesan){
        System.out.println(pesan);
    }
}
