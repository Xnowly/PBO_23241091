package com.tutorial;

public class BangunDatar {
    // Atribut
    public float luas;
    public float keliling;

    
}
